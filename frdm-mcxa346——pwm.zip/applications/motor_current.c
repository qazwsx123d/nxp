/*
 * motor_current.c - 电机电流采样模块实现
 * 基于 RT-Thread ADC 设备框架
 */
#include "motor_current.h"

/* ==================== 硬件配置 ==================== */
#define CURRENT_ADC_DEV_NAME    "adc0"      /* ADC设备名 */
#define CURRENT_ADC_CHANNEL     3           /* ADC通道 (根据实际接线修改) */

/* 滤波配置 */
#define CURRENT_FILTER_SIZE     8           /* 滑动平均滤波窗口 */

/* ==================== 私有变量 ==================== */
static rt_adc_device_t adc_dev = RT_NULL;
static float current_limit = CURRENT_LIMIT_DEFAULT;
static float filter_buf[CURRENT_FILTER_SIZE] = {0};
static rt_uint8_t filter_idx = 0;
static float filtered_current = 0.0f;

/* ==================== 私有函数 ==================== */

/* 滑动平均滤波 */
static float current_filter_update(float new_val)
{
    float sum = 0.0f;

    filter_buf[filter_idx] = new_val;
    filter_idx = (filter_idx + 1) % CURRENT_FILTER_SIZE;

    for (int i = 0; i < CURRENT_FILTER_SIZE; i++)
    {
        sum += filter_buf[i];
    }

    return sum / CURRENT_FILTER_SIZE;
}

/* ==================== 公共函数 ==================== */

rt_err_t motor_current_init(void)
{
    /* 查找 ADC 设备 */
    adc_dev = (rt_adc_device_t)rt_device_find(CURRENT_ADC_DEV_NAME);
    if (adc_dev == RT_NULL)
    {
        rt_kprintf("[Current] Error: ADC device %s not found!\n", CURRENT_ADC_DEV_NAME);
        return -RT_ENOSYS;
    }

    /* 使能 ADC 通道 */
    rt_adc_enable(adc_dev, CURRENT_ADC_CHANNEL);

    /* 清空滤波缓冲 */
    for (int i = 0; i < CURRENT_FILTER_SIZE; i++)
    {
        filter_buf[i] = 0.0f;
    }
    filter_idx = 0;
    filtered_current = 0.0f;

    rt_kprintf("[Current] ADC initialized. Channel: %d, Limit: %.2f A\n",
               CURRENT_ADC_CHANNEL, current_limit);
    return RT_EOK;
}

rt_uint32_t motor_current_read_raw(void)
{
    if (adc_dev == RT_NULL) return 0;

    return rt_adc_read(adc_dev, CURRENT_ADC_CHANNEL);
}

float motor_current_read(void)
{
    rt_uint32_t adc_val;
    float voltage;
    float current;

    if (adc_dev == RT_NULL) return 0.0f;

    /* 读取ADC值 */
    adc_val = rt_adc_read(adc_dev, CURRENT_ADC_CHANNEL);

    /* 转换为电压: V = (ADC / 4095) * Vref */
    voltage = ((float)adc_val / CURRENT_ADC_MAX) * CURRENT_VREF;

    /* 转换为电流: I = V / (R * Gain) */
    current = voltage / (CURRENT_SHUNT_RESISTANCE * CURRENT_GAIN);

    /* 更新滤波值 */
    filtered_current = current_filter_update(current);

    return current;
}

float motor_current_get_filtered(void)
{
    return filtered_current;
}

void motor_current_set_limit(float limit_a)
{
    if (limit_a < 0.0f) limit_a = 0.0f;
    if (limit_a > CURRENT_LIMIT_MAX) limit_a = CURRENT_LIMIT_MAX;

    current_limit = limit_a;
    rt_kprintf("[Current] Limit set to %.2f A\n", current_limit);
}

float motor_current_get_limit(void)
{
    return current_limit;
}

rt_bool_t motor_current_is_overcurrent(void)
{
    return (filtered_current > current_limit) ? RT_TRUE : RT_FALSE;
}
