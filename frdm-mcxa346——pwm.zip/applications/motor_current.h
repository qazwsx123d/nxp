/*
 * motor_current.h - 电机电流采样模块
 * 功能：ADC采样、滤波、限流保护
 */
#ifndef __MOTOR_CURRENT_H__
#define __MOTOR_CURRENT_H__

#include <rtthread.h>
#include <rtdevice.h>

/* 电流采样配置 */
#define CURRENT_SHUNT_RESISTANCE    0.1f    /* 分流电阻 0.1 Ohm */
#define CURRENT_GAIN                1.0f    /* 放大倍数 (无放大=1) */
#define CURRENT_VREF                3.3f    /* ADC参考电压 */
#define CURRENT_ADC_MAX             4095    /* 12位ADC最大值 */

/* 限流配置 */
#define CURRENT_LIMIT_DEFAULT       1.0f    /* 默认限流值 1A */
#define CURRENT_LIMIT_MAX           2.0f    /* 最大允许电流 2A */

/* 初始化电流采样 */
rt_err_t motor_current_init(void);

/* 读取电流值 (单位: A) */
float motor_current_read(void);

/* 读取ADC原始值 */
rt_uint32_t motor_current_read_raw(void);

/* 设置限流值 */
void motor_current_set_limit(float limit_a);

/* 获取限流值 */
float motor_current_get_limit(void);

/* 检查是否过流 */
rt_bool_t motor_current_is_overcurrent(void);

/* 获取滤波后的电流值 */
float motor_current_get_filtered(void);

#endif /* __MOTOR_CURRENT_H__ */
