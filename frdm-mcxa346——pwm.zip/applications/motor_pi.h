/*
 * motor_pi.h - PI 速度控制器
 * 功能：PI控制、反积分饱和
 */
#ifndef __MOTOR_PI_H__
#define __MOTOR_PI_H__

#include <rtthread.h>

/* PI 控制器结构 */
typedef struct {
    float kp;           /* 比例系数 */
    float ki;           /* 积分系数 */
    float integral;     /* 积分累积值 */
    float out_min;      /* 输出下限 */
    float out_max;      /* 输出上限 */
    float last_error;   /* 上次误差 (用于调试) */
    float output;       /* 当前输出 */
} motor_pi_t;

/* 初始化 PI 控制器 */
void motor_pi_init(motor_pi_t *pi, float kp, float ki, float out_min, float out_max);

/* PI 控制器计算
 * @param pi    控制器结构指针
 * @param ref   目标值 (设定值)
 * @param fb    反馈值 (测量值)
 * @param ts    采样周期 (秒)
 * @return      控制输出
 */
float motor_pi_update(motor_pi_t *pi, float ref, float fb, float ts);

/* 重置积分项 */
void motor_pi_reset(motor_pi_t *pi);

/* 设置 PI 参数 */
void motor_pi_set_gains(motor_pi_t *pi, float kp, float ki);

/* 设置输出限幅 */
void motor_pi_set_limits(motor_pi_t *pi, float out_min, float out_max);

#endif /* __MOTOR_PI_H__ */
