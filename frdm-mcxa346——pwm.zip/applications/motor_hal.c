/*
 * motor_hal.c - 电机硬件抽象层实现
 * 基于 RT-Thread PWM 设备框架 + GPIO 控制
 */
#include "motor_hal.h"
#include "fsl_common.h"
#include "fsl_port.h"
#include "fsl_clock.h"
#include "fsl_gpio.h"

/* ==================== 硬件配置 ==================== */
/* PWM 配置 (使用 FlexPWM0) */
#define MOTOR_PWM_DEV_NAME      "pwm0"
#define MOTOR_PWM_CHANNEL       1           /* PWM 通道 */
#define MOTOR_PWM_FREQ_HZ       20000       /* 20kHz PWM频率 */
#define MOTOR_PWM_PERIOD_NS     (1000000000UL / MOTOR_PWM_FREQ_HZ)

/* PWM 引脚配置: P3_0 */
#define MOTOR_PWM_PORT          PORT3
#define MOTOR_PWM_PIN           0U
#define MOTOR_PWM_PIN_ALT       kPORT_MuxAlt5
#define MOTOR_PWM_PORT_CLK      kCLOCK_GateGPIO3

/* H桥方向控制引脚 (TB6612/DRV8833) */
/* AIN1: P3_12 */
#define MOTOR_AIN1_PORT         PORT3
#define MOTOR_AIN1_GPIO         GPIO3
#define MOTOR_AIN1_PIN          12U
#define MOTOR_AIN1_PORT_CLK     kCLOCK_GateGPIO3

/* AIN2: P3_13 */
#define MOTOR_AIN2_PORT         PORT3
#define MOTOR_AIN2_GPIO         GPIO3
#define MOTOR_AIN2_PIN          13U
#define MOTOR_AIN2_PORT_CLK     kCLOCK_GateGPIO3

/* ==================== 私有变量 ==================== */
static struct rt_device_pwm *pwm_dev = RT_NULL;
static motor_state_t motor_state = {
    .direction = MOTOR_DIR_COAST,
    .duty = 0.0f,
    .enabled = RT_FALSE
};

/* ==================== 私有函数 ==================== */

/* 初始化 PWM 引脚复用 */
static void motor_pwm_pin_init(void)
{
    CLOCK_EnableClock(MOTOR_PWM_PORT_CLK);
    PORT_SetPinMux(MOTOR_PWM_PORT, MOTOR_PWM_PIN, MOTOR_PWM_PIN_ALT);
}

/* 初始化方向控制 GPIO */
static void motor_gpio_init(void)
{
    gpio_pin_config_t gpio_cfg = {
        .pinDirection = kGPIO_DigitalOutput,
        .outputLogic = 0U
    };

    /* AIN1 */
    CLOCK_EnableClock(MOTOR_AIN1_PORT_CLK);
    PORT_SetPinMux(MOTOR_AIN1_PORT, MOTOR_AIN1_PIN, kPORT_MuxAsGpio);
    GPIO_PinInit(MOTOR_AIN1_GPIO, MOTOR_AIN1_PIN, &gpio_cfg);

    /* AIN2 */
    CLOCK_EnableClock(MOTOR_AIN2_PORT_CLK);
    PORT_SetPinMux(MOTOR_AIN2_PORT, MOTOR_AIN2_PIN, kPORT_MuxAsGpio);
    GPIO_PinInit(MOTOR_AIN2_GPIO, MOTOR_AIN2_PIN, &gpio_cfg);
}

/* ==================== 公共函数 ==================== */

rt_err_t motor_hal_init(void)
{
    /* 初始化引脚 */
    motor_pwm_pin_init();
    motor_gpio_init();

    /* 查找 PWM 设备 */
    pwm_dev = (struct rt_device_pwm *)rt_device_find(MOTOR_PWM_DEV_NAME);
    if (pwm_dev == RT_NULL)
    {
        rt_kprintf("[Motor] Error: PWM device %s not found!\n", MOTOR_PWM_DEV_NAME);
        return -RT_ENOSYS;
    }

    /* 设置初始状态：空转，占空比0 */
    motor_set_direction(MOTOR_DIR_COAST);
    motor_set_duty(0.0f);

    rt_kprintf("[Motor] HAL initialized. PWM freq: %d Hz\n", MOTOR_PWM_FREQ_HZ);
    return RT_EOK;
}

void motor_set_direction(motor_dir_t dir)
{
    /*
     * TB6612/DRV8833 逻辑:
     * 正转:   AIN1=1, AIN2=0
     * 反转:   AIN1=0, AIN2=1
     * 刹车:   AIN1=1, AIN2=1
     * 空转:   AIN1=0, AIN2=0
     */
    switch (dir)
    {
    case MOTOR_DIR_FWD:
        GPIO_PinWrite(MOTOR_AIN1_GPIO, MOTOR_AIN1_PIN, 1);
        GPIO_PinWrite(MOTOR_AIN2_GPIO, MOTOR_AIN2_PIN, 0);
        break;
    case MOTOR_DIR_REV:
        GPIO_PinWrite(MOTOR_AIN1_GPIO, MOTOR_AIN1_PIN, 0);
        GPIO_PinWrite(MOTOR_AIN2_GPIO, MOTOR_AIN2_PIN, 1);
        break;
    case MOTOR_DIR_BRAKE:
        GPIO_PinWrite(MOTOR_AIN1_GPIO, MOTOR_AIN1_PIN, 1);
        GPIO_PinWrite(MOTOR_AIN2_GPIO, MOTOR_AIN2_PIN, 1);
        break;
    case MOTOR_DIR_COAST:
    default:
        GPIO_PinWrite(MOTOR_AIN1_GPIO, MOTOR_AIN1_PIN, 0);
        GPIO_PinWrite(MOTOR_AIN2_GPIO, MOTOR_AIN2_PIN, 0);
        break;
    }
    motor_state.direction = dir;
}

void motor_set_duty(float duty)
{
    rt_uint32_t pulse_ns;

    /* 限幅 */
    if (duty < 0.0f) duty = 0.0f;
    if (duty > 1.0f) duty = 1.0f;

    motor_state.duty = duty;

    if (pwm_dev == RT_NULL) return;

    /* 计算脉宽 */
    pulse_ns = (rt_uint32_t)(MOTOR_PWM_PERIOD_NS * duty);
    rt_pwm_set(pwm_dev, MOTOR_PWM_CHANNEL, MOTOR_PWM_PERIOD_NS, pulse_ns);
}

void motor_enable(void)
{
    if (pwm_dev == RT_NULL) return;

    rt_pwm_enable(pwm_dev, MOTOR_PWM_CHANNEL);
    motor_state.enabled = RT_TRUE;
    rt_kprintf("[Motor] Enabled\n");
}

void motor_disable(void)
{
    if (pwm_dev == RT_NULL) return;

    rt_pwm_disable(pwm_dev, MOTOR_PWM_CHANNEL);
    motor_state.enabled = RT_FALSE;
    rt_kprintf("[Motor] Disabled\n");
}

motor_state_t motor_get_state(void)
{
    return motor_state;
}

void motor_emergency_stop(void)
{
    /* 立即刹车 */
    motor_set_duty(0.0f);
    motor_set_direction(MOTOR_DIR_BRAKE);
    motor_disable();
    rt_kprintf("[Motor] EMERGENCY STOP!\n");
}
