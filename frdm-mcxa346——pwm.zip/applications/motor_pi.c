/*
 * motor_pi.c - PI 速度控制器实现
 * 带反积分饱和 (Anti-windup)
 */
#include "motor_pi.h"

void motor_pi_init(motor_pi_t *pi, float kp, float ki, float out_min, float out_max)
{
    if (pi == RT_NULL) return;

    pi->kp = kp;
    pi->ki = ki;
    pi->integral = 0.0f;
    pi->out_min = out_min;
    pi->out_max = out_max;
    pi->last_error = 0.0f;
    pi->output = 0.0f;
}

float motor_pi_update(motor_pi_t *pi, float ref, float fb, float ts)
{
    float error;
    float p_term;
    float output;

    if (pi == RT_NULL) return 0.0f;

    /* 计算误差 */
    error = ref - fb;
    pi->last_error = error;

    /* 比例项 */
    p_term = pi->kp * error;

    /* 积分项累加 */
    pi->integral += pi->ki * error * ts;

    /* 反积分饱和：限制积分项 */
    if (pi->integral > pi->out_max)
    {
        pi->integral = pi->out_max;
    }
    else if (pi->integral < pi->out_min)
    {
        pi->integral = pi->out_min;
    }

    /* 计算输出 */
    output = p_term + pi->integral;

    /* 输出限幅 */
    if (output > pi->out_max)
    {
        output = pi->out_max;
    }
    else if (output < pi->out_min)
    {
        output = pi->out_min;
    }

    pi->output = output;
    return output;
}

void motor_pi_reset(motor_pi_t *pi)
{
    if (pi == RT_NULL) return;

    pi->integral = 0.0f;
    pi->last_error = 0.0f;
    pi->output = 0.0f;
}

void motor_pi_set_gains(motor_pi_t *pi, float kp, float ki)
{
    if (pi == RT_NULL) return;

    pi->kp = kp;
    pi->ki = ki;
}

void motor_pi_set_limits(motor_pi_t *pi, float out_min, float out_max)
{
    if (pi == RT_NULL) return;

    pi->out_min = out_min;
    pi->out_max = out_max;
}
