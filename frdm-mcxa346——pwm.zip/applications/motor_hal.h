/*
 * motor_hal.h - 电机硬件抽象层
 * 功能：PWM调速、方向控制、刹车/空转
 */
#ifndef __MOTOR_HAL_H__
#define __MOTOR_HAL_H__

#include <rtthread.h>
#include <rtdevice.h>

/* 电机方向定义 */
typedef enum {
    MOTOR_DIR_COAST = 0,    /* 空转 */
    MOTOR_DIR_FWD,          /* 正转 */
    MOTOR_DIR_REV,          /* 反转 */
    MOTOR_DIR_BRAKE         /* 刹车 */
} motor_dir_t;

/* 电机状态结构 */
typedef struct {
    motor_dir_t direction;      /* 当前方向 */
    float duty;                 /* 当前占空比 0.0~1.0 */
    rt_bool_t enabled;          /* 是否使能 */
} motor_state_t;

/* 初始化电机硬件 */
rt_err_t motor_hal_init(void);

/* 设置电机方向 */
void motor_set_direction(motor_dir_t dir);

/* 设置PWM占空比 (0.0 ~ 1.0) */
void motor_set_duty(float duty);

/* 使能/禁用电机 */
void motor_enable(void);
void motor_disable(void);

/* 获取电机状态 */
motor_state_t motor_get_state(void);

/* 紧急停止 */
void motor_emergency_stop(void);

#endif /* __MOTOR_HAL_H__ */
