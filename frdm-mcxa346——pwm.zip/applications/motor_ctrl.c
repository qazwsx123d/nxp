/*
 * motor_ctrl.c - 电机控制主模块
 * 功能：控制线程、PI闭环、串口命令菜单
 *
 * 使用方法 (FinSH 命令):
 *   motor init          - 初始化电机控制
 *   motor start         - 启动控制线程
 *   motor stop          - 停止控制线程
 *   motor dir fwd/rev/brake/coast - 设置方向
 *   motor duty <0-100>  - 设置占空比 (开环模式)
 *   motor rpm <value>   - 设置目标转速 (闭环模式)
 *   motor ilim <value>  - 设置限流值 (A)
 *   motor pid <kp> <ki> - 设置PI参数
 *   motor mode open/close - 切换开环/闭环模式
 *   motor info          - 显示状态信息
 */
#include <rtthread.h>
#include <rtdevice.h>
#include <stdlib.h>
#include <string.h>

#include "motor_hal.h"
#include "motor_current.h"
#include "motor_speed.h"
#include "motor_pi.h"

/* ==================== 配置参数 ==================== */
#define MOTOR_CTRL_THREAD_STACK     1024
#define MOTOR_CTRL_THREAD_PRIO      15
#define MOTOR_CTRL_PERIOD_MS        10      /* 控制周期 10ms */

/* PI 默认参数 */
#define MOTOR_PI_KP_DEFAULT         0.002f
#define MOTOR_PI_KI_DEFAULT         0.001f

/* 软启动斜率限制 */
#define MOTOR_DUTY_RAMP_STEP        0.02f   /* 每周期最大变化 2% */

/* ==================== 控制模式 ==================== */
typedef enum {
    MOTOR_MODE_OPEN = 0,    /* 开环模式 */
    MOTOR_MODE_CLOSED       /* 闭环模式 */
} motor_mode_t;

/* ==================== 私有变量 ==================== */
static rt_thread_t ctrl_thread = RT_NULL;
static volatile rt_bool_t ctrl_running = RT_FALSE;
static volatile rt_bool_t motor_initialized = RT_FALSE;

static motor_mode_t ctrl_mode = MOTOR_MODE_OPEN;
static motor_pi_t speed_pi;

static float target_duty = 0.0f;        /* 目标占空比 (开环) */
static float target_rpm = 0.0f;         /* 目标转速 (闭环) */
static float current_duty = 0.0f;       /* 当前占空比 (带斜率限制) */

/* 过流保护计数 */
static rt_uint32_t overcurrent_count = 0;
#define OVERCURRENT_THRESHOLD   5       /* 连续N次过流触发保护 */

/* ==================== 控制线程 ==================== */
static void motor_ctrl_thread_entry(void *param)
{
    float measured_rpm;
    float measured_current;
    float pi_output;
    float duty_target;
    float ts = MOTOR_CTRL_PERIOD_MS / 1000.0f;

    rt_kprintf("[Motor] Control thread started.\n");

    while (ctrl_running)
    {
        /* 1. 更新速度测量 */
        motor_speed_update();
        measured_rpm = motor_speed_get_rpm();

        /* 2. 读取电流 */
        measured_current = motor_current_read();

        /* 3. 过流保护检测 */
        if (motor_current_is_overcurrent())
        {
            overcurrent_count++;
            if (overcurrent_count >= OVERCURRENT_THRESHOLD)
            {
                rt_kprintf("[Motor] OVERCURRENT! I=%.2fA, Limit=%.2fA\n",
                           measured_current, motor_current_get_limit());
                /* 降低占空比 */
                target_duty *= 0.5f;
                if (ctrl_mode == MOTOR_MODE_CLOSED)
                {
                    motor_pi_reset(&speed_pi);
                }
                overcurrent_count = 0;
            }
        }
        else
        {
            overcurrent_count = 0;
        }

        /* 4. 计算目标占空比 */
        if (ctrl_mode == MOTOR_MODE_CLOSED)
        {
            /* 闭环模式：PI 控制 */
            pi_output = motor_pi_update(&speed_pi, target_rpm, measured_rpm, ts);
            duty_target = pi_output;
        }
        else
        {
            /* 开环模式：直接使用目标占空比 */
            duty_target = target_duty;
        }

        /* 5. 软启动：斜率限制 */
        if (duty_target > current_duty + MOTOR_DUTY_RAMP_STEP)
        {
            current_duty += MOTOR_DUTY_RAMP_STEP;
        }
        else if (duty_target < current_duty - MOTOR_DUTY_RAMP_STEP)
        {
            current_duty -= MOTOR_DUTY_RAMP_STEP;
        }
        else
        {
            current_duty = duty_target;
        }

        /* 6. 限幅 */
        if (current_duty < 0.0f) current_duty = 0.0f;
        if (current_duty > 1.0f) current_duty = 1.0f;

        /* 7. 输出到电机 */
        motor_set_duty(current_duty);

        /* 等待下一周期 */
        rt_thread_mdelay(MOTOR_CTRL_PERIOD_MS);
    }

    /* 停止时安全处理 */
    motor_set_duty(0.0f);
    motor_set_direction(MOTOR_DIR_COAST);
    motor_disable();

    rt_kprintf("[Motor] Control thread stopped.\n");
}

/* ==================== 初始化函数 ==================== */
static rt_err_t motor_ctrl_init(void)
{
    rt_err_t ret;

    if (motor_initialized)
    {
        rt_kprintf("[Motor] Already initialized.\n");
        return RT_EOK;
    }

    /* 初始化各模块 */
    ret = motor_hal_init();
    if (ret != RT_EOK)
    {
        rt_kprintf("[Motor] HAL init failed!\n");
        return ret;
    }

    ret = motor_current_init();
    if (ret != RT_EOK)
    {
        rt_kprintf("[Motor] Current sensor init failed!\n");
        /* 继续运行，电流采样可选 */
    }

    ret = motor_speed_init();
    if (ret != RT_EOK)
    {
        rt_kprintf("[Motor] Speed sensor init failed!\n");
        /* 继续运行，测速可选 */
    }

    /* 初始化 PI 控制器 */
    motor_pi_init(&speed_pi, MOTOR_PI_KP_DEFAULT, MOTOR_PI_KI_DEFAULT, 0.0f, 1.0f);

    motor_initialized = RT_TRUE;
    rt_kprintf("[Motor] Initialization complete.\n");
    return RT_EOK;
}

/* ==================== FinSH 命令 ==================== */
static void motor(int argc, char **argv)
{
    if (argc < 2)
    {
        rt_kprintf("Usage:\n");
        rt_kprintf("  motor init              - Initialize motor control\n");
        rt_kprintf("  motor start             - Start control thread\n");
        rt_kprintf("  motor stop              - Stop control thread\n");
        rt_kprintf("  motor dir <fwd|rev|brake|coast> - Set direction\n");
        rt_kprintf("  motor duty <0-100>      - Set duty cycle (open-loop)\n");
        rt_kprintf("  motor rpm <value>       - Set target RPM (closed-loop)\n");
        rt_kprintf("  motor ilim <value>      - Set current limit (A)\n");
        rt_kprintf("  motor pid <kp> <ki>     - Set PI gains\n");
        rt_kprintf("  motor mode <open|close> - Set control mode\n");
        rt_kprintf("  motor info              - Show status\n");
        rt_kprintf("  motor estop             - Emergency stop\n");
        return;
    }

    /* motor init */
    if (rt_strcmp(argv[1], "init") == 0)
    {
        motor_ctrl_init();
    }
    /* motor start */
    else if (rt_strcmp(argv[1], "start") == 0)
    {
        if (!motor_initialized)
        {
            rt_kprintf("[Motor] Not initialized! Run 'motor init' first.\n");
            return;
        }
        if (ctrl_running)
        {
            rt_kprintf("[Motor] Already running.\n");
            return;
        }

        ctrl_running = RT_TRUE;
        ctrl_thread = rt_thread_create("motor_ctrl",
                                       motor_ctrl_thread_entry,
                                       RT_NULL,
                                       MOTOR_CTRL_THREAD_STACK,
                                       MOTOR_CTRL_THREAD_PRIO,
                                       10);
        if (ctrl_thread != RT_NULL)
        {
            motor_enable();
            rt_thread_startup(ctrl_thread);
        }
        else
        {
            ctrl_running = RT_FALSE;
            rt_kprintf("[Motor] Failed to create thread!\n");
        }
    }
    /* motor stop */
    else if (rt_strcmp(argv[1], "stop") == 0)
    {
        if (!ctrl_running)
        {
            rt_kprintf("[Motor] Not running.\n");
            return;
        }
        ctrl_running = RT_FALSE;
        /* 等待线程退出 */
        rt_thread_mdelay(MOTOR_CTRL_PERIOD_MS * 3);
    }
    /* motor dir <fwd|rev|brake|coast> */
    else if (rt_strcmp(argv[1], "dir") == 0)
    {
        if (argc < 3)
        {
            rt_kprintf("Usage: motor dir <fwd|rev|brake|coast>\n");
            return;
        }
        if (rt_strcmp(argv[2], "fwd") == 0)
        {
            motor_set_direction(MOTOR_DIR_FWD);
            rt_kprintf("[Motor] Direction: FORWARD\n");
        }
        else if (rt_strcmp(argv[2], "rev") == 0)
        {
            motor_set_direction(MOTOR_DIR_REV);
            rt_kprintf("[Motor] Direction: REVERSE\n");
        }
        else if (rt_strcmp(argv[2], "brake") == 0)
        {
            motor_set_direction(MOTOR_DIR_BRAKE);
            rt_kprintf("[Motor] Direction: BRAKE\n");
        }
        else if (rt_strcmp(argv[2], "coast") == 0)
        {
            motor_set_direction(MOTOR_DIR_COAST);
            rt_kprintf("[Motor] Direction: COAST\n");
        }
        else
        {
            rt_kprintf("Unknown direction: %s\n", argv[2]);
        }
    }
    /* motor duty <0-100> */
    else if (rt_strcmp(argv[1], "duty") == 0)
    {
        if (argc < 3)
        {
            rt_kprintf("Usage: motor duty <0-100>\n");
            return;
        }
        int duty_pct = atoi(argv[2]);
        if (duty_pct < 0) duty_pct = 0;
        if (duty_pct > 100) duty_pct = 100;
        target_duty = duty_pct / 100.0f;
        rt_kprintf("[Motor] Target duty: %d%%\n", duty_pct);
    }
    /* motor rpm <value> */
    else if (rt_strcmp(argv[1], "rpm") == 0)
    {
        if (argc < 3)
        {
            rt_kprintf("Usage: motor rpm <value>\n");
            return;
        }
        target_rpm = (float)atof(argv[2]);
        if (target_rpm < 0) target_rpm = 0;
        rt_kprintf("[Motor] Target RPM: %.1f\n", target_rpm);
    }
    /* motor ilim <value> */
    else if (rt_strcmp(argv[1], "ilim") == 0)
    {
        if (argc < 3)
        {
            rt_kprintf("Usage: motor ilim <value_in_amps>\n");
            return;
        }
        float ilim = (float)atof(argv[2]);
        motor_current_set_limit(ilim);
    }
    /* motor pid <kp> <ki> */
    else if (rt_strcmp(argv[1], "pid") == 0)
    {
        if (argc < 4)
        {
            rt_kprintf("Usage: motor pid <kp> <ki>\n");
            rt_kprintf("Current: Kp=%.4f, Ki=%.4f\n", speed_pi.kp, speed_pi.ki);
            return;
        }
        float kp = (float)atof(argv[2]);
        float ki = (float)atof(argv[3]);
        motor_pi_set_gains(&speed_pi, kp, ki);
        rt_kprintf("[Motor] PI gains: Kp=%.4f, Ki=%.4f\n", kp, ki);
    }
    /* motor mode <open|close> */
    else if (rt_strcmp(argv[1], "mode") == 0)
    {
        if (argc < 3)
        {
            rt_kprintf("Usage: motor mode <open|close>\n");
            rt_kprintf("Current mode: %s\n", ctrl_mode == MOTOR_MODE_OPEN ? "OPEN" : "CLOSED");
            return;
        }
        if (rt_strcmp(argv[2], "open") == 0)
        {
            ctrl_mode = MOTOR_MODE_OPEN;
            rt_kprintf("[Motor] Mode: OPEN-LOOP\n");
        }
        else if (rt_strcmp(argv[2], "close") == 0)
        {
            ctrl_mode = MOTOR_MODE_CLOSED;
            motor_pi_reset(&speed_pi);
            rt_kprintf("[Motor] Mode: CLOSED-LOOP\n");
        }
        else
        {
            rt_kprintf("Unknown mode: %s\n", argv[2]);
        }
    }
    /* motor info */
    else if (rt_strcmp(argv[1], "info") == 0)
    {
        motor_state_t state = motor_get_state();
        const char *dir_str[] = {"COAST", "FWD", "REV", "BRAKE"};

        rt_kprintf("========== Motor Status ==========\n");
        rt_kprintf("Initialized: %s\n", motor_initialized ? "YES" : "NO");
        rt_kprintf("Running:     %s\n", ctrl_running ? "YES" : "NO");
        rt_kprintf("Mode:        %s\n", ctrl_mode == MOTOR_MODE_OPEN ? "OPEN-LOOP" : "CLOSED-LOOP");
        rt_kprintf("Direction:   %s\n", dir_str[state.direction]);
        rt_kprintf("Enabled:     %s\n", state.enabled ? "YES" : "NO");
        rt_kprintf("----------------------------------\n");
        rt_kprintf("Target Duty: %.1f%%\n", target_duty * 100.0f);
        rt_kprintf("Current Duty:%.1f%%\n", current_duty * 100.0f);
        rt_kprintf("Target RPM:  %.1f\n", target_rpm);
        rt_kprintf("Actual RPM:  %.1f\n", motor_speed_get_rpm());
        rt_kprintf("----------------------------------\n");
        rt_kprintf("Current:     %.3f A\n", motor_current_get_filtered());
        rt_kprintf("Current Lim: %.2f A\n", motor_current_get_limit());
        rt_kprintf("Pulse Count: %u\n", motor_speed_get_pulse_count());
        rt_kprintf("----------------------------------\n");
        rt_kprintf("PI Kp:       %.4f\n", speed_pi.kp);
        rt_kprintf("PI Ki:       %.4f\n", speed_pi.ki);
        rt_kprintf("PI Integral: %.4f\n", speed_pi.integral);
        rt_kprintf("==================================\n");
    }
    /* motor estop */
    else if (rt_strcmp(argv[1], "estop") == 0)
    {
        ctrl_running = RT_FALSE;
        target_duty = 0.0f;
        target_rpm = 0.0f;
        current_duty = 0.0f;
        motor_emergency_stop();
    }
    else
    {
        rt_kprintf("Unknown command: %s\n", argv[1]);
    }
}

/* 导出 FinSH 命令 */
MSH_CMD_EXPORT(motor, Motor control: motor <cmd> [args]);

/* ==================== 主函数 ==================== */
int main(void)
{
    rt_kprintf("\n");
    rt_kprintf("========================================\n");
    rt_kprintf("  FRDM-MCXA346 Motor Control Demo\n");
    rt_kprintf("  Based on RT-Thread\n");
    rt_kprintf("========================================\n");
    rt_kprintf("\n");
    rt_kprintf("Commands:\n");
    rt_kprintf("  motor init   - Initialize\n");
    rt_kprintf("  motor start  - Start control\n");
    rt_kprintf("  motor info   - Show status\n");
    rt_kprintf("  motor help   - Show all commands\n");
    rt_kprintf("\n");

    return 0;
}
