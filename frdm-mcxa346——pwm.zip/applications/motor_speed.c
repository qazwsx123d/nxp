/*
 * motor_speed.c - 电机速度测量模块实现
 * 基于 RT-Thread PIN 设备框架 + 脉冲计数
 */
#include "motor_speed.h"
#include <rtdevice.h>
#include "drv_pin.h"

/* ==================== 硬件配置 ==================== */
/* 霍尔/码盘输入引脚: P3_14 -> PIN号 = 3*32+14 = 110 */
#define SPEED_HALL_PIN          ((3*32)+14)

/* ==================== 私有变量 ==================== */
static volatile rt_uint32_t pulse_count = 0;        /* 脉冲计数 */
static volatile rt_uint32_t last_pulse_count = 0;   /* 上次脉冲计数 */
static rt_uint32_t ppr = SPEED_PPR;                 /* 每转脉冲数 */
static float current_rpm = 0.0f;                    /* 当前转速 */
static float current_hz = 0.0f;                     /* 当前频率 */

/* 滤波缓冲 */
static float rpm_filter_buf[SPEED_FILTER_SIZE] = {0};
static rt_uint8_t filter_idx = 0;

/* ==================== 中断回调 ==================== */
static void speed_hall_irq_callback(void *args)
{
    /* 脉冲计数 +1 */
    pulse_count++;
}

/* ==================== 私有函数 ==================== */

/* 滑动平均滤波 */
static float speed_filter_update(float new_val)
{
    float sum = 0.0f;

    rpm_filter_buf[filter_idx] = new_val;
    filter_idx = (filter_idx + 1) % SPEED_FILTER_SIZE;

    for (int i = 0; i < SPEED_FILTER_SIZE; i++)
    {
        sum += rpm_filter_buf[i];
    }

    return sum / SPEED_FILTER_SIZE;
}

/* ==================== 公共函数 ==================== */

rt_err_t motor_speed_init(void)
{
    /* 配置引脚为输入，带上拉 */
    rt_pin_mode(SPEED_HALL_PIN, PIN_MODE_INPUT_PULLUP);

    /* 绑定下降沿中断 */
    rt_pin_attach_irq(SPEED_HALL_PIN, PIN_IRQ_MODE_FALLING, speed_hall_irq_callback, RT_NULL);

    /* 使能中断 */
    rt_pin_irq_enable(SPEED_HALL_PIN, PIN_IRQ_ENABLE);

    /* 清零计数 */
    pulse_count = 0;
    last_pulse_count = 0;
    current_rpm = 0.0f;
    current_hz = 0.0f;

    /* 清空滤波缓冲 */
    for (int i = 0; i < SPEED_FILTER_SIZE; i++)
    {
        rpm_filter_buf[i] = 0.0f;
    }
    filter_idx = 0;

    rt_kprintf("[Speed] Initialized. PPR: %d\n", ppr);
    return RT_EOK;
}

void motor_speed_update(void)
{
    rt_uint32_t delta_pulse;
    float raw_rpm;

    /* 计算脉冲增量 */
    rt_base_t level = rt_hw_interrupt_disable();
    delta_pulse = pulse_count - last_pulse_count;
    last_pulse_count = pulse_count;
    rt_hw_interrupt_enable(level);

    /*
     * 计算转速:
     * 频率 Hz = delta_pulse / (SAMPLE_PERIOD_MS / 1000)
     * RPM = Hz * 60 / PPR
     */
    current_hz = (float)delta_pulse * 1000.0f / SPEED_SAMPLE_PERIOD_MS;
    raw_rpm = current_hz * 60.0f / ppr;

    /* 滤波 */
    current_rpm = speed_filter_update(raw_rpm);
}

float motor_speed_get_rpm(void)
{
    return current_rpm;
}

float motor_speed_get_hz(void)
{
    return current_hz;
}

rt_uint32_t motor_speed_get_pulse_count(void)
{
    return pulse_count;
}

void motor_speed_reset_count(void)
{
    rt_base_t level = rt_hw_interrupt_disable();
    pulse_count = 0;
    last_pulse_count = 0;
    rt_hw_interrupt_enable(level);
}

void motor_speed_set_ppr(rt_uint32_t new_ppr)
{
    if (new_ppr > 0)
    {
        ppr = new_ppr;
        rt_kprintf("[Speed] PPR set to %d\n", ppr);
    }
}
