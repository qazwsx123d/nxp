/*
 * motor_speed.h - 电机速度测量模块
 * 功能：霍尔/码盘测速、RPM计算
 */
#ifndef __MOTOR_SPEED_H__
#define __MOTOR_SPEED_H__

#include <rtthread.h>
#include <rtdevice.h>

/* 测速配置 */
#define SPEED_PPR               20          /* 每转脉冲数 (Pulses Per Revolution) */
#define SPEED_SAMPLE_PERIOD_MS  10          /* 采样周期 ms */
#define SPEED_FILTER_SIZE       4           /* 滤波窗口大小 */

/* 初始化速度测量 */
rt_err_t motor_speed_init(void);

/* 获取当前转速 (RPM) */
float motor_speed_get_rpm(void);

/* 获取当前频率 (Hz) */
float motor_speed_get_hz(void);

/* 获取脉冲计数 */
rt_uint32_t motor_speed_get_pulse_count(void);

/* 清零脉冲计数 */
void motor_speed_reset_count(void);

/* 设置每转脉冲数 */
void motor_speed_set_ppr(rt_uint32_t ppr);

/* 速度测量更新 (需要周期性调用或在定时器中调用) */
void motor_speed_update(void);

#endif /* __MOTOR_SPEED_H__ */
